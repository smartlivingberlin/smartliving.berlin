window.$crisp=[];window.CRISP_WEBSITE_ID="ce8f2b1d-c3f4-4bec-95ae-0a1f10f2f507";
window.addEventListener("load",function(){ window.$crisp.push(["do","chat:show"]); });
window.CRISP_RUNTIME_CONFIG = { locale: 'de' };
(function(){
  var d=document,s=d.createElement("script");
  s.src="https://client.crisp.chat/l.js"; s.async=1;
  s.onload=function(){ console.log("CRISP: l.js geladen ✔"); };
  d.getElementsByTagName("head")[0].appendChild(s);
})();
